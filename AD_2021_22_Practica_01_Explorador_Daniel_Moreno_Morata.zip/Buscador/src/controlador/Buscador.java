package controlador;
import java.io.*;
import java.util.*;
public class Buscador {
    
    
    public static void main(String[] args) {
        //iniciacion de la interfaz
        Vista vista = new Vista();
        vista.setVisible(true);    
    }
}

    

