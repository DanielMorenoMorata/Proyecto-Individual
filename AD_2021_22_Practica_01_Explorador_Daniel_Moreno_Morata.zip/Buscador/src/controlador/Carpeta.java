/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;
import java.io.Serializable;

/**
 *
 * @author eldai
 */
public class Carpeta implements Serializable{
    
    //delcaracion
    
    private String Nombre, Extension, Tamaño, FicDir;

    public Carpeta(String Nombre, String Extension, String Tamaño, String FicDir) {
        this.Nombre = Nombre;
        this.Extension = Extension;
        this.Tamaño = Tamaño;
        this.FicDir = FicDir;
    }

    //geters y seters
    
    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getExtension() {
        return Extension;
    }

    public void setExtension(String Extension) {
        this.Extension = Extension;
    }

    public String getTamaño() {
        return Tamaño;
    }

    public void setTamaño(String Tamaño) {
        this.Tamaño = Tamaño;
    }

    public String getFicDir() {
        return FicDir;
    }

    public void setFicDir(String FicDir) {
        this.FicDir = FicDir;
    }

}
